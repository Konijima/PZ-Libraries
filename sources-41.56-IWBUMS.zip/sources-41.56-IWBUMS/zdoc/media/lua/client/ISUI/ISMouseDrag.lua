
---@class ISMouseDrag
ISMouseDrag = {}

ISMouseDrag.dragView = nil;
