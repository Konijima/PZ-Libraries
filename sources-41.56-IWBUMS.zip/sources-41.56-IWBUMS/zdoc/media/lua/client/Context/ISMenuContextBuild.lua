--***********************************************************
--**                    THE INDIE STONE                    **
--**				  Author: turbotutone				   **
--***********************************************************

---@class ISMenuContextBuild
ISMenuContextBuild = {};

function ISMenuContextBuild.new()
	local self 					= ISMenuElement.new();
	
	function self.init()
		--self.loadElements( _table_ );
	end	

	function self.createMenu()
	end
		
	return self;
end	
